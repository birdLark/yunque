业务层的命名和数据层的命名的区别：
比如login()方法 和selectByUserNameAndPassword() 方法 
