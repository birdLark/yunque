export LANG=en_US.UTF-8

export JAVA_HOME=/home/yunque/jdk
export PATH=$JAVA_HOME/bin:$PATH
export CLASSPATH=.:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar


export PATH=${PATH}:/home/yunque/bin


